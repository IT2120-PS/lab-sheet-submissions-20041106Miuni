getwd()
setwd("C:\\Users\\IT24101073\\Desktop\\IT24101073")


# Load the laptop weights data
weights <- scan("Exercise - LaptopsWeights.txt", skip = 1)


# Step 1: Calculate population mean and standard deviation
population_mean <- mean(weights)  # Mean of all weights
population_sd <- sd(weights)      # Standard deviation of all weights

# Display population statistics
cat("Population Mean:", population_mean, "\n")
cat("Population Standard Deviation:", population_sd, "\n")


# Step 2: Draw 25 random samples of size 6 (with replacement)
set.seed(123)  # Set seed for reproducibility
sample_means <- numeric(25)  # Empty vector to store sample means
sample_sds <- numeric(25)    # Empty vector to store sample standard deviations

for (i in 1:25) {
  sample <- sample(weights, size = 6, replace = TRUE)  # Random sample of size 6
  
  sample_means[i] <- mean(sample)                      # Mean of the sample
  sample_sds[i] <- sd(sample)                          # Standard deviation of the sample
}


# Step 3: Calculate mean and standard deviation of the sample means
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

# Display sample statistics
cat("Mean of 25 Sample Means:", mean_of_sample_means, "\n")
cat("Standard Deviation of Sample Means:", sd_of_sample_means, "\n")


# Step 4: Relationship explanation
cat("\nRelationship:\n")
cat("The mean of the sample means is close to the population mean (Law of Large Numbers).\n")
cat("The standard deviation of the sample means (standard error) is smaller than the population standard deviation.\n")
cat("It approximates population_sd / sqrt(sample size).\n")


