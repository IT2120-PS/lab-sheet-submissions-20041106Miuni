getwd()
setwd("C:\\Users\\IT24101073\\Desktop\\IT24101073")
data <- read.csv("Exercise.txt", header = TRUE)
head(data)

boxplot(data$Advertising_X2, main = "Advertising Budget", ylab = "Budget", col = "lightgreen")
summary(data$Sales_X1)
sd(data$Sales_X1)

summary(data$Advertising_X2)
sd(data$Advertising_X2)

summary(data$Years_X3)
sd(data$Years_X3)

get_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  outliers <- x[x < lb | x > ub]
  return(outliers)
}

# Check for outliers in Years_X3
get_outliers(data$Years_X3)