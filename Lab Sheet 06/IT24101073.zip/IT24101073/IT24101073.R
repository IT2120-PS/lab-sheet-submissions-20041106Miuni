getwd()
setwd("C:\\Users\\IT24101073\\Desktop\\IT24101073")
# Parameters
n <- 50
p <- 0.85

# (i) Distribution of X: Binomial(n=50, p=0.85)
cat("X follows Binomial distribution with n =", n, "and p =", p, "\n")

# (ii) Probability that at least 47 students passed
prob_at_least_47 <- 1 - pbinom(46, size=n, prob=p)
cat("Probability that at least 47 students passed the test:", prob_at_least_47, "\n")


# Given
lambda <- 12

# (i) Random variable X: number of calls received in an hour
cat("Random variable X = number of calls received in one hour\n")

# (ii) Distribution of X: Poisson with mean lambda = 12
cat("X follows a Poisson distribution with lambda =", lambda, "\n")

# (iii) Probability that exactly 15 calls are received
prob_15_calls <- dpois(15, lambda=lambda)
cat("Probability of receiving exactly 15 calls in an hour:", prob_15_calls, "\n")
