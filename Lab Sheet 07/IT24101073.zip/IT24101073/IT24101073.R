getwd()
setwd("C:\\Users\\User\\Desktop\\IT24101073")
# Train arrival uniformly between 0 and 40 minutes
a <- 0
b <- 40
p <- (25 - 10) / (b - a)
p
# Exponential distribution with rate = 1/3
lambda <- 1/3
p <- pexp(2, rate = lambda)   # P(X ≤ 2)
p

mu <- 100
sigma <- 15
p1 <- 1 - pnorm(130, mean = mu, sd = sigma)
p1
q <- qnorm(0.95, mean = mu, sd = sigma)
q